<?php
$options   = [];
$options[] = array(
	'id'          => 'penci_popup_enable',
	'default'     => false,
	'sanitize'    => 'penci_sanitize_checkbox_field',
	'label'       => __( 'Enable Promo Popup', 'soledad' ),
	'description' => __( 'Show promo popup to users when they enter the site.', 'soledad' ),
	'section'     => 'penci_popup_section_general',
	'type'        => 'soledad-fw-toggle',
);
$options[] = array(
	'id'          => 'penci_popup_disable_mobile',
	'default'     => false,
	'sanitize'    => 'penci_sanitize_checkbox_field',
	'label'       => __( 'Hide for Mobile Devices', 'soledad' ),
	'description' => __( 'You can disable this option for mobile devices completely.', 'soledad' ),
	'section'     => 'penci_popup_section_general',
	'type'        => 'soledad-fw-toggle',
);

return $options;
